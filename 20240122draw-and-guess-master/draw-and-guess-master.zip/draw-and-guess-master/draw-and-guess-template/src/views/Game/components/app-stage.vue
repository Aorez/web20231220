<template>
  <el-card ref="wrapper" :body-style="{ padding: 0 }">
    <div style="height: 600px;">画布</div>
  </el-card>
</template>

<script>
export default {
  data() {
    return {

    }
  },

  computed: {

  },

  mounted() {

  },

  methods: {

  }
}
</script>
